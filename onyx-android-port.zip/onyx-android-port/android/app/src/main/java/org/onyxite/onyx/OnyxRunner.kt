package org.onyxite.onyx

import android.content.Context
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File

sealed interface RunEvent {
    data class Line(val text: String) : RunEvent
    data class Done(val exitCode: Int) : RunEvent
}

/**
 * Runs the `onyx-cli` executable, bundled as jniLibs/arm64-v8a/libonyx.so
 * (see scripts/build-android-onyx.sh). No JNI or FFI: it is a plain child process.
 */
class OnyxRunner(private val context: Context) {
    private val binary = File(context.applicationInfo.nativeLibraryDir, "libonyx.so")
    private val resourcesDir = File(context.filesDir, "onyx-resources")
    private val versionMarker = File(context.filesDir, "onyx-resources.version")

    val isInstalled: Boolean get() = binary.exists()

    /** Copies assets/onyx-resources into app storage once per app version. */
    suspend fun prepareResources() = withContext(Dispatchers.IO) {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        val version = PackageInfoCompat.getLongVersionCode(info).toString()
        if (resourcesDir.exists() && versionMarker.exists() && versionMarker.readText() == version) return@withContext
        resourcesDir.deleteRecursively()
        copyAssetDir("onyx-resources", resourcesDir)
        versionMarker.writeText(version)
    }

    private fun copyAssetDir(assetPath: String, dest: File) {
        val children = context.assets.list(assetPath).orEmpty()
        if (children.isNotEmpty()) {
            dest.mkdirs()
            children.forEach { copyAssetDir("$assetPath/$it", File(dest, it)) }
        } else {
            runCatching {
                dest.parentFile?.mkdirs()
                context.assets.open(assetPath).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            }.onFailure { dest.mkdirs() } // empty folder
        }
    }

    fun run(args: List<String>, workDir: File): Flow<RunEvent> = flow {
        val pb = ProcessBuilder(listOf(binary.path) + args)
            .directory(workDir)
            .redirectErrorStream(true)
        pb.environment().apply {
            put("HOME", context.filesDir.path)
            put("TMPDIR", context.cacheDir.path) // Haskell's temp dir defaults to /tmp, which Android lacks
            put("ONYX_RESOURCES", resourcesDir.path) // needs patches/0001-resources-env-override.patch
            put("LANG", "C.UTF-8")
        }
        val process = pb.start()
        try {
            val reader = process.inputStream.bufferedReader()
            while (true) {
                val line = reader.readLine() ?: break
                emit(RunEvent.Line(line))
            }
            emit(RunEvent.Done(process.waitFor()))
        } finally {
            process.destroy()
        }
    }.flowOn(Dispatchers.IO)
}
