package org.onyxite.onyx

import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import java.io.File

// Palette: a quiet stage, with the fret colors used only to say which task is active.
private val Stage = Color(0xFF14161A)
private val Panel = Color(0xFF1E2127)
private val Ink = Color(0xFFECEEF2)
private val Muted = Color(0xFF9AA1AD)
private val FretGreen = Color(0xFF43B86B)
private val FretYellow = Color(0xFFE8B931)

/** Every task is one Onyx CLI command. Adding a feature means adding a row here. */
private enum class Task(val label: String, val hint: String, val runLabel: String, val color: Color) {
    Preview("Preview", "Play a song's chart in the built-in player.", "Open player", FretGreen),
    Convert("Quick Convert", "Repack a Rock Band song for another console.", "Convert", FretYellow),
}

private val formats = listOf("CON" to "Xbox 360", "PKG" to "PS3")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val runner = OnyxRunner(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Stage, surface = Panel)) {
                Surface(Modifier.fillMaxSize(), color = Stage, contentColor = Ink) { OnyxApp(runner) }
            }
        }
    }
}

@Composable
private fun OnyxApp(runner: OnyxRunner) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var task by remember { mutableStateOf(Task.Preview) }
    var format by remember { mutableStateOf(formats[0].first) }
    var inputUri by remember { mutableStateOf<Uri?>(null) }
    var inputName by remember { mutableStateOf<String?>(null) }
    var running by remember { mutableStateOf(false) }
    var playerIndex by remember { mutableStateOf<File?>(null) }
    var pendingOutput by remember { mutableStateOf<File?>(null) }
    val log = remember { mutableStateListOf<String>() }
    val logState = rememberLazyListState()

    val pickInput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            inputUri = uri
            inputName = context.displayName(uri)
        }
    }
    val saveOutput = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        val file = pendingOutput
        if (uri != null && file != null) scope.launch {
            context.exportFile(file, uri)
            log.add("Saved ${context.displayName(uri)}")
        }
    }

    LaunchedEffect(log.size) { if (log.isNotEmpty()) logState.animateScrollToItem(log.lastIndex) }

    fun start() {
        val uri = inputUri ?: return
        val name = inputName ?: "input"
        scope.launch {
            running = true
            log.clear()
            if (!runner.isInstalled) {
                log.add("libonyx.so is not in this build. See PORTING.md, step 1.")
                running = false
                return@launch
            }
            runner.prepareResources()
            val work = File(context.cacheDir, "work").apply { deleteRecursively(); mkdirs() }
            val input = File(work, "in/$name")
            context.importUri(uri, input)

            val output = when (task) {
                Task.Preview -> File(work, "player")
                Task.Convert -> File(work, "out/${name}_${format.lowercase()}")
            }
            output.parentFile?.mkdirs()
            val args = when (task) {
                Task.Preview -> listOf("web-player", input.path, "--to", output.path)
                // "quick-convert" does not exist in the CLI yet; see PORTING.md, step 3.
                Task.Convert -> listOf("quick-convert", input.path, "--format", format.lowercase(), "--to", output.path)
            }

            // The CLI ends with "Done! Created files:" followed by one path per line.
            val created = mutableListOf<String>()
            var listing = false
            var exit = -1
            runner.run(args, work).collect { event ->
                when (event) {
                    is RunEvent.Line -> {
                        log.add(event.text)
                        if (listing && event.text.isNotBlank()) created.add(event.text.trim())
                        if (event.text.startsWith("Done! Created files:")) listing = true
                    }
                    is RunEvent.Done -> exit = event.exitCode
                }
            }
            running = false

            if (exit != 0) {
                log.add("Failed with exit code $exit.")
            } else if (task == Task.Preview) {
                val index = created.firstOrNull { it.endsWith("index.html") }
                if (index != null) playerIndex = File(index) else log.add("The player was not created.")
            } else {
                val file = created.firstOrNull()
                if (file != null) {
                    pendingOutput = File(file)
                    saveOutput.launch(File(file).name)
                } else {
                    log.add("No output file was created.")
                }
            }
        }
    }

    val index = playerIndex
    if (index != null) {
        PlayerScreen(index) { playerIndex = null }
        return
    }

    Column(
        Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Onyx", fontSize = 28.sp, fontWeight = FontWeight.SemiBold)

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Task.entries.forEach { t ->
                Tile(t.label, null, t == task, t.color, Modifier.weight(1f)) { task = t }
            }
        }
        Text(task.hint, color = Muted, fontSize = 15.sp)

        Tile(
            title = inputName ?: "Choose a song file",
            subtitle = if (inputName == null) "Tap to open the file picker" else "Tap to choose another",
            selected = inputName != null,
            color = task.color,
            modifier = Modifier.fillMaxWidth(),
        ) { pickInput.launch(arrayOf("*/*")) }

        if (task == Task.Convert) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                formats.forEach { (code, console) ->
                    Tile(code, console, code == format, task.color, Modifier.weight(1f)) { format = code }
                }
            }
        }

        LazyColumn(
            state = logState,
            modifier = Modifier.weight(1f).fillMaxWidth()
                .background(Panel, RoundedCornerShape(12.dp)).padding(12.dp),
        ) {
            items(log) { Text(it, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Muted) }
        }

        // The main action sits at the bottom, inside thumb reach.
        Button(
            onClick = { start() },
            enabled = inputUri != null && !running,
            modifier = Modifier.fillMaxWidth().height(64.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = task.color, contentColor = Stage),
        ) { Text(if (running) "Working..." else task.runLabel, fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }
    }
}

/** A touch target of at least 72dp. Selection is shown by a colored bar plus a tint, never by hover. */
@Composable
private fun Tile(
    title: String,
    subtitle: String?,
    selected: Boolean,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier
            .heightIn(min = 72.dp)
            .background(if (selected) color.copy(alpha = 0.16f) else Panel, shape)
            .clickable(onClick = onClick),
    ) {
        Box(Modifier.fillMaxWidth().height(4.dp).background(if (selected) color else Color.Transparent))
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 2)
            if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = Muted)
        }
    }
}

@Composable
private fun PlayerScreen(index: File, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.allowFileAccess = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    // The player loads song.js and audio-*.js with <script> tags, so file:// works.
                    loadUrl(Uri.fromFile(index).toString())
                }
            },
        )
        Button(
            onClick = onClose,
            modifier = Modifier.fillMaxWidth().padding(12.dp).height(56.dp),
            shape = RoundedCornerShape(14.dp),
        ) { Text("Close player", fontSize = 17.sp) }
    }
}
