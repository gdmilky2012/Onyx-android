package org.onyxite.onyx

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Name the user sees in the Android file picker, e.g. "song_rb3con". */
fun Context.displayName(uri: Uri): String =
    contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: uri.lastPathSegment ?: "input"

/** Onyx wants real paths, but the picker gives content:// URIs, so copy into app storage. */
suspend fun Context.importUri(uri: Uri, dest: File) = withContext(Dispatchers.IO) {
    dest.parentFile?.mkdirs()
    contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
}

suspend fun Context.exportFile(src: File, uri: Uri) = withContext(Dispatchers.IO) {
    contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { i -> i.copyTo(o) } }
}
