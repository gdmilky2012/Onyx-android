plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "org.onyxite.onyx"
    compileSdk = 34

    defaultConfig {
        applicationId = "org.onyxite.onyx"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "20261016-android0"
        ndk { abiFilters += "arm64-v8a" }
    }

    buildFeatures { compose = true }

    // libonyx.so is an executable, not a JNI library. Android only lets an app
    // exec files from nativeLibraryDir, and only if they are extracted to disk.
    packaging { jniLibs { useLegacyPackaging = true } }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
