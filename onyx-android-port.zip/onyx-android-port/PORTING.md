# Port Onyx 20261016 ke Android: kerangka awal

**Status: belum di-compile dan belum diuji.** Ini dibuat tanpa GHC, Android NDK, atau Android SDK.
Yang sudah ada: aplikasi Android dengan UI sentuh, pemanggil Onyx CLI, dan satu patch Haskell.
Yang belum ada: binary Onyx untuk Android (langkah 1) dan perintah `quick-convert` (langkah 3).

## Pendekatan

Onyx tidak di-port sebagai satu program. Aplikasi Android (Kotlin/Compose) menjalankan `onyx-cli`
sebagai proses anak, jadi tidak perlu JNI atau FFI. Executable-nya dikemas sebagai
`libonyx.so` karena Android hanya mengizinkan exec dari `nativeLibraryDir`.

## Temuan dari source

- `onyx-lib` (inti, sekitar 85 ribu baris Haskell) tidak bergantung pada GUI. Target `onyx-cli`
  hanya memakai `onyx-lib`, jadi FLTK, OpenGL, OpenAL, dan SDL tidak perlu dibawa ke Android.
- GUI desktop (`onyx-exe-toolkit`, sekitar 4 ribu baris Haskell, widget C++ FLTK, layout `.fl`)
  tidak bisa dipindah. Preview bawaannya memakai OpenGL 3.3 core dan OpenAL. Semuanya diganti
  UI Compose + web player.
- Web player PureScript (`player/`) sudah menangani `touchstart`, punya meta viewport mobile, dan
  memuat data/audio lewat tag `<script>`, jadi bisa langsung dibuka di WebView lewat `file://`.
- Library native yang dibutuhkan CLI: FFmpeg (avutil, avformat, avcodec, swscale, avfilter,
  swresample), ogg, vorbis, vorbisenc, vorbisfile. Mungkin ada tambahan; cek `onyx-lib`.
- `getResourcesPath` mencari `onyx-resources` di sebelah executable. Di Android folder itu
  read-only, jadi ada patch `patches/0001-resources-env-override.patch` (variabel `ONYX_RESOURCES`).
- Haskell memakai `/tmp` sebagai folder sementara. Android tidak punya `/tmp`, jadi `OnyxRunner`
  mengatur `TMPDIR` ke cache aplikasi.
- Quick Convert hanya ada di GUI. Perintah CLI-nya belum ada (di `CommandLine.hs` hanya ada
  komentar `TODO "convert" command`).
- Zip dari GitHub tidak berisi submodule (FFmpeg, ogg, vorbis, dll.). Gunakan
  `git clone --recursive`.

## Langkah berikutnya

1. **Cross-compile `onyx-cli` ke aarch64-android.** Ini bagian paling berisiko. Butuh GHC 9.6.6
   cross-compiler untuk Android (stack/ghcup tidak menyediakannya langsung), library C dari NDK,
   dan kemungkinan menyesuaikan build `inline-c`/Template Haskell. Garis besar ada di
   `scripts/build-android-onyx.sh`.
2. Terapkan patch resource: `git apply patches/0001-resources-env-override.patch`.
3. **Tambah perintah `quick-convert`** di `Onyx/CommandLine.hs`. Titik masuknya sudah ada di
   `Onyx/QuickConvert/RockBand.hs`: `loadQuickInput`, lalu `saveQuickSongsSTFS` (CON) atau
   `saveQuickSongsPKG` (PS3). Kontrak yang dipakai UI:
   `onyx quick-convert <input> --format con|pkg --to <output>`.
4. Salin `haskell/resources` dan `resources-cli` ke `app/src/main/assets/onyx-resources/`.
   Buang file `.exe` Windows (magma, makefsb4, xma2encode).
5. Buka folder `android/` di Android Studio. Versi Gradle/Compose di file ini perlu dinaikkan
   bila sudah usang.

## Fitur lain

`Task` di `MainActivity.kt` adalah daftar perintah. Menambah fitur (misalnya `import`, `build`,
`extract`) berarti menambah satu baris di sana dan satu cabang argumen. Fitur yang hanya ada di
GUI (batch, pengeditan lagu) perlu perintah CLI baru seperti Quick Convert.

## Risiko yang diketahui

- Exec dari `nativeLibraryDir` jalan untuk instalasi manual, tetapi aturan Android/Play Store
  bisa berubah.
- File CON/PKG disalin ke cache sebelum diproses, jadi butuh ruang sekitar dua kali ukuran file.
- Belum ada tombol batal untuk proses yang sedang berjalan.
- Onyx berlisensi GPL v3. Jika APK dibagikan, kode sumber lengkap beserta patch ini harus
  disediakan.
