#!/usr/bin/env bash
# OUTLINE, NOT RUN. Written without an NDK or a GHC cross-compiler available.
# Goal: produce android/app/src/main/jniLibs/arm64-v8a/libonyx.so from the `onyx-cli` executable.
set -euo pipefail

: "${ANDROID_NDK_HOME:?set to your NDK folder}"
: "${ONYX_SRC:?set to an Onyx checkout made with: git clone --recursive https://github.com/mtolly/onyx}"
: "${GHC_ANDROID:?set to a GHC 9.6.6 cross-compiler targeting aarch64-linux-android}"

API=26
TRIPLE=aarch64-linux-android
TOOLCHAIN="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64"
export CC="$TOOLCHAIN/bin/${TRIPLE}${API}-clang"
export AR="$TOOLCHAIN/bin/llvm-ar"
export RANLIB="$TOOLCHAIN/bin/llvm-ranlib"
PREFIX="$PWD/android-deps"
mkdir -p "$PREFIX"

# 1. Let the host app say where onyx-resources lives.
git -C "$ONYX_SRC" apply "$PWD/patches/0001-resources-env-override.patch"

# 2. Native libraries used by onyx-cli (static, so libonyx.so has no extra .so files to ship).
D="$ONYX_SRC/haskell/dependencies/libs"
for lib in ogg vorbis; do
  ( cd "$D/$lib" && ./autogen.sh 2>/dev/null || true
    ./configure --host=$TRIPLE --prefix="$PREFIX" --enable-static --disable-shared
    make -j"$(nproc)" install )
done
( cd "$D/FFmpeg" && ./configure --enable-cross-compile --arch=aarch64 --target-os=android \
    --cc="$CC" --ar="$AR" --ranlib="$RANLIB" --prefix="$PREFIX" \
    --enable-static --disable-shared --disable-programs --disable-doc --enable-pic
  make -j"$(nproc)" install )
# TODO: check onyx-lib and onyx-ffmpeg for anything else (LAME, libsamplerate, rubberband, freetype).

# 3. The blocker: build onyx-cli with a cross GHC. Stack's LTS 22.34 resolver is host-only,
#    so this uses cabal with the generated haskell/cabal.project.
export PKG_CONFIG_PATH="$PREFIX/lib/pkgconfig"
( cd "$ONYX_SRC/haskell" && cabal build onyx-cli \
    --with-compiler="$GHC_ANDROID" \
    --extra-lib-dirs="$PREFIX/lib" --extra-include-dirs="$PREFIX/include" )

# 4. Ship it. The name must be lib*.so so Android extracts it into nativeLibraryDir.
BIN="$(cd "$ONYX_SRC/haskell" && cabal list-bin onyx-cli --with-compiler="$GHC_ANDROID")"
install -D "$BIN" "$PWD/android/app/src/main/jniLibs/arm64-v8a/libonyx.so"

# 5. Resources: copy only what the CLI needs on Android. Skip the Windows .exe files
#    (magma-*, makefsb4, xma2encode); they cannot run here.
#    cp -R "$ONYX_SRC/haskell/resources/." android/app/src/main/assets/onyx-resources/
#    cp -R "$ONYX_SRC/haskell/resources-cli/." android/app/src/main/assets/onyx-resources/
echo "Now open android/ in Android Studio and run the app."
